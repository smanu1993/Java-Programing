package coding;

public class Vehicle {
    public void move(String name){
        System.out.println(name+" is moving"+" from vehicle");
    }
}
